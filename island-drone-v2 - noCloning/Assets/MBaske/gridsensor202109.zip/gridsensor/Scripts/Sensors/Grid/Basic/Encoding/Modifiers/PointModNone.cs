
namespace MBaske.Sensors.Grid
{
    /// <summary>
    /// Does nothing.
    /// </summary>
    public class PointModNone : PointModifier { }
}