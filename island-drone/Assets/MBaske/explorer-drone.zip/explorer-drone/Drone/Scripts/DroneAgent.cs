using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using UnityEngine;

public class DroneAgent : Agent
{
    public DroneData Data { get; private set; }
    public Drone Drone { get; private set; }
    public BlockWorld World { get; private set; }
    public Cam Cam { get; private set; }
    
    [SerializeField]
    [Range(2f, 10f)]
    private float lookRadius = 5f;
    [SerializeField]
    [Range(0.25f, 1f)]
    private float leafNodeSize = 0.5f;

    private Point scanPoint;
    private Vector3Int prevPos;
    private int lingerCount; 

    private void OnValidate()
    {
        leafNodeSize = Mathf.Pow(2f, Mathf.Round(Mathf.Log(leafNodeSize, 2f)));
    }

    public override void Initialize()
    {
        Data = new DroneData();

        Drone = GetComponentInChildren<Drone>();
        Drone.Initialize();
        World = GetComponentInChildren<BlockWorld>();
        World.Initialize();
        Cam = GetComponentInChildren<Cam>();
        Cam.Initialize();
    }

    // reset drone, world and camera
    // QUESTION: what is scanPoint and prevPos? 
    public override void OnEpisodeBegin()
    {
        Data.Reset(Drone.Position, lookRadius, leafNodeSize);

        Drone.ReSet();
        World.ReSet();
        Cam.ReSet();

        scanPoint = default(Point);
        prevPos = GetVector3Int(Drone.Position);
        lingerCount = 0;
    }
    
    // why does the position need to be divided by the leaf node size in GetVector3Int?
    
    // if drone is in new position add it to Data
    // QUESTION: why drone also adds the scanpoint ?
    // check how many new leaf nodes in scan
    // QUESTION: reward = nodecount / look radius
    
    // QUESTION: what is stepupdate
    // drone has a penalty for lingering in the same gridblock
    // QUESTION: drone gets a penalty for promixity (why multiplied by velocity?)
    
    // observations
    // QUESTION: why obs linger -1f
    // QUESTION: how does the obs proximity bring anything to the drone?
    // QUESTION: what is proximity.w * 2f - 1?
    // what are the IntersectRatios
    // What is the scanBuffer? the whole scanned area?
    // what is the point of "LookRadiusNorm" as an observation?
    // how do the above observations motivate the drone to explore better? i think that it could already scan very well 
    // with half of all these observations?
    public override void CollectObservations(VectorSensor sensor)
    {
        Vector3 pos = Drone.Position;
        if (IsNewGridPosition(pos))
        {
            Data.AddPoint(new Point(PointType.DronePos, pos, Time.time));
        }

        Data.AddPoint(scanPoint);
        // Number of new leaf nodes created by this scan.
        int nodeCount = Data.Tree.Intersect(pos, scanPoint.Position);
        float scanReward = (nodeCount * 0.1f) / Data.LookRadius;
        AddReward(scanReward);
        
        Data.StepUpdate(pos);

        float linger = lingerCount / 100f; // 0 - 2
        float lingerPenalty = -linger * 0.1f;
        AddReward(lingerPenalty);

        Vector3 velocity = Drone.VelocityNorm;
        Vector4 proximity = Drone.GetForwardProximity();
        float proxPenalty = (1f - 1f / Mathf.Max(proximity.w, 0.1f)) * velocity.sqrMagnitude * 0.25f;
        AddReward(proxPenalty);

        sensor.AddObservation(linger - 1f); // 1
        sensor.AddObservation(velocity); // 3 
        sensor.AddObservation((Vector3)proximity); // 3
        sensor.AddObservation(proximity.w * 2f - 1f); // 1 
        sensor.AddObservation(Data.LookRadiusNorm); // 1 
        sensor.AddObservation(Data.NodeDensities); // 8
        sensor.AddObservation(Data.IntersectRatios); // 8 
        sensor.AddObservation(Drone.ScanBuffer.ToArray()); // 30
    }

    // public override void OnActionReceived(float[] vectorAction)
    // {
    //     scanPoint = Drone.Scan(vectorAction[0], vectorAction[1], Data.LookRadius);
    //     Drone.Move(new Vector3(vectorAction[2], vectorAction[3], vectorAction[4]));
    //
    //     if (!World.StepUpdate())
    //     {
    //         OnEpisodeBegin();
    //     }
    // }

    private bool IsNewGridPosition(Vector3 dronePos)
    {
        Vector3Int pos = GetVector3Int(dronePos);
        if (pos != prevPos)
        {
            prevPos = pos;
            lingerCount = 0;
            return true;
        }

        lingerCount = Mathf.Min(200, lingerCount + 1);
        return false;
    }

    private Vector3Int GetVector3Int(Vector3 pos)
    {
        float s = Data.LeafNodeSize;
        return new Vector3Int(
            Mathf.RoundToInt(pos.x / s),
            Mathf.RoundToInt(pos.y / s),
            Mathf.RoundToInt(pos.z / s)
        );
    }
}
