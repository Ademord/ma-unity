﻿namespace Popcron.Gizmos
{
    public class Constants
    {
        public const string UniqueIdentifier = "Popcron.Gizmos";
        public const string EnabledKey = UniqueIdentifier + ".Enabled";
    }
}